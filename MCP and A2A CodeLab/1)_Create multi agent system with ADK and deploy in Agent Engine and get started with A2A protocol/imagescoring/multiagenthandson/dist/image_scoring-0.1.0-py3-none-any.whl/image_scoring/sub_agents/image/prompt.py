IMAGEGEN_PROMPT = """
Your job is to invoke the 'generate_images' tool by passing the `image generation prompt` provided 
to you as a parameter .
"""
